location_choices = {
    "Mumbai": "Mumbai",
    "Pune": "Pune",
    "Bangalore": "Bangalore",
    "Remote": "Remote"
}

contract_choices = {
    "Full Time": "Full Time",
    "Part Time": "Part Time",
    "Freelance": "Freelance"
}